import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, CheckCircle2, XCircle, Clock } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Logs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [successFilter, setSuccessFilter] = useState("all");

  const { data: logs, isLoading } = useQuery({
    queryKey: ["/api/logs/usage", { search: searchQuery, success: successFilter }],
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-page-title">Redemption Logs</h1>
        <p className="text-muted-foreground">View all discount redemption attempts</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>All Redemption Attempts</CardTitle>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by code..."
                  className="pl-9 w-full sm:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value.toUpperCase())}
                  data-testid="input-search-logs"
                />
              </div>
              <Select value={successFilter} onValueChange={setSuccessFilter}>
                <SelectTrigger className="w-full sm:w-[150px]" data-testid="select-success-filter">
                  <SelectValue placeholder="Result" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Results</SelectItem>
                  <SelectItem value="success">Success Only</SelectItem>
                  <SelectItem value="failure">Failures Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(10)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : logs && logs.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Result</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Cashier</TableHead>
                  <TableHead>Template</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Error</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log: any, index: number) => (
                  <TableRow key={log.id} data-testid={`row-log-${index}`}>
                    <TableCell>
                      {log.success ? (
                        <div className="flex items-center gap-2 text-chart-2">
                          <CheckCircle2 className="h-4 w-4" />
                          <span className="font-medium">Success</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-destructive">
                          <XCircle className="h-4 w-4" />
                          <span className="font-medium">Failed</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="font-mono font-bold">
                      {log.attemptCode}
                    </TableCell>
                    <TableCell>
                      {log.user ? (
                        <div>
                          <p className="font-medium">{log.user.firstName} {log.user.lastName}</p>
                          <p className="text-xs text-muted-foreground">@{log.user.username}</p>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {log.cashier ? (
                        <div>
                          <p className="font-medium">{log.cashier.firstName} {log.cashier.lastName}</p>
                          <p className="text-xs text-muted-foreground">@{log.cashier.username}</p>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {log.template?.name || <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(log.createdAt).toLocaleString()}
                      </div>
                    </TableCell>
                    <TableCell>
                      {log.errorCode || log.errorMessage ? (
                        <div className="max-w-xs">
                          {log.errorCode && (
                            <Badge variant="destructive" className="mb-1">
                              {log.errorCode}
                            </Badge>
                          )}
                          {log.errorMessage && (
                            <p className="text-xs text-muted-foreground truncate">
                              {log.errorMessage}
                            </p>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No logs found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
