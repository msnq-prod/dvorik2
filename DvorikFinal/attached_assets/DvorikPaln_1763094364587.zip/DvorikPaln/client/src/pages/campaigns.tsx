import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Copy, ExternalLink, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Campaigns() {
  const { toast } = useToast();
  const { data: campaigns, isLoading } = useQuery({
    queryKey: ["/api/campaigns"],
  });

  const copyLink = (botUsername: string, code: string) => {
    const link = `https://t.me/${botUsername}?start=ref_${code}`;
    navigator.clipboard.writeText(link);
    toast({
      title: "Link copied",
      description: "Referral link copied to clipboard",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-page-title">Referral Campaigns</h1>
          <p className="text-muted-foreground">Track referral link performance</p>
        </div>
        <Button data-testid="button-create-campaign">
          <Plus className="h-4 w-4 mr-2" />
          Create Campaign
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          [...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-24 mt-2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ))
        ) : campaigns && campaigns.length > 0 ? (
          campaigns.map((campaign: any, index: number) => (
            <Card key={campaign.id} data-testid={`card-campaign-${index}`} className="flex flex-col">
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-lg">{campaign.name}</CardTitle>
                  {campaign.isActive ? (
                    <Badge variant="default">Active</Badge>
                  ) : (
                    <Badge variant="secondary">Inactive</Badge>
                  )}
                </div>
                {campaign.description && (
                  <CardDescription className="line-clamp-2">{campaign.description}</CardDescription>
                )}
              </CardHeader>
              <CardContent className="flex-1 space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-3 rounded-md bg-muted">
                    <div className="text-2xl font-bold">{campaign.clickCount}</div>
                    <div className="text-xs text-muted-foreground">Clicks</div>
                  </div>
                  <div className="text-center p-3 rounded-md bg-muted">
                    <div className="text-2xl font-bold">{campaign.registrationCount}</div>
                    <div className="text-xs text-muted-foreground">Registrations</div>
                  </div>
                  <div className="text-center p-3 rounded-md bg-muted">
                    <div className="text-2xl font-bold">{campaign.redemptionCount}</div>
                    <div className="text-xs text-muted-foreground">Redemptions</div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Conversion:</span>
                    <span className="font-semibold">
                      {campaign.clickCount > 0 
                        ? `${((campaign.registrationCount / campaign.clickCount) * 100).toFixed(1)}%`
                        : "0%"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Redemption Rate:</span>
                    <span className="font-semibold">
                      {campaign.registrationCount > 0 
                        ? `${((campaign.redemptionCount / campaign.registrationCount) * 100).toFixed(1)}%`
                        : "0%"}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t">
                  <p className="text-xs font-mono text-muted-foreground mb-2">
                    Code: {campaign.code}
                  </p>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => copyLink("your_bot", campaign.code)}
                      data-testid={`button-copy-link-${index}`}
                    >
                      <Copy className="h-3 w-3 mr-1" />
                      Copy Link
                    </Button>
                    <Button size="sm" variant="outline" data-testid={`button-view-campaign-${index}`}>
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="text-xs text-muted-foreground border-t pt-4">
                Created {new Date(campaign.createdAt).toLocaleDateString()}
              </CardFooter>
            </Card>
          ))
        ) : (
          <Card className="col-span-full">
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No campaigns found. Create your first campaign to get started.</p>
              <Button className="mt-4" data-testid="button-create-first-campaign">
                <Plus className="h-4 w-4 mr-2" />
                Create Campaign
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
