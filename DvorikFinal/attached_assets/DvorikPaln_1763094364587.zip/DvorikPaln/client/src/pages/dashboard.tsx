import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, Gift, MessageSquare, TrendingUp } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats/overview"],
  });

  const { data: recentRedemptions, isLoading: redemptionsLoading } = useQuery({
    queryKey: ["/api/discounts/recent-redemptions"],
  });

  const { data: pendingCashiers, isLoading: cashiersLoading } = useQuery({
    queryKey: ["/api/cashiers/pending"],
  });

  const statCards = [
    {
      title: "Total Users",
      value: stats?.totalUsers || 0,
      icon: Users,
      trend: "+12%",
      color: "text-chart-1",
    },
    {
      title: "Active Discounts",
      value: stats?.activeDiscounts || 0,
      icon: Gift,
      trend: "+8%",
      color: "text-chart-2",
    },
    {
      title: "Redemptions (Today)",
      value: stats?.todayRedemptions || 0,
      icon: TrendingUp,
      trend: "+23%",
      color: "text-chart-3",
    },
    {
      title: "Broadcasts Sent",
      value: stats?.broadcastsSent || 0,
      icon: MessageSquare,
      trend: "+5%",
      color: "text-chart-4",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-page-title">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to Marmalade Courtyard admin panel</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat, index) => (
          <Card key={index} data-testid={`card-stat-${index}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <>
                  <div className="text-2xl font-bold" data-testid={`text-stat-${index}`}>
                    {stat.value.toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-chart-2">{stat.trend}</span> from last month
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Redemptions & Pending Approvals */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Recent Redemptions */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Redemptions</CardTitle>
          </CardHeader>
          <CardContent>
            {redemptionsLoading ? (
              <div className="space-y-2">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : recentRedemptions && recentRedemptions.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Cashier</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentRedemptions.map((redemption: any, index: number) => (
                    <TableRow key={index} data-testid={`row-redemption-${index}`}>
                      <TableCell className="font-mono font-bold">
                        {redemption.code}
                      </TableCell>
                      <TableCell>{redemption.userName}</TableCell>
                      <TableCell>{redemption.cashierName}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {new Date(redemption.redeemedAt).toLocaleTimeString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No redemptions yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pending Cashier Approvals */}
        <Card>
          <CardHeader>
            <CardTitle>Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            {cashiersLoading ? (
              <div className="space-y-2">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : pendingCashiers && pendingCashiers.length > 0 ? (
              <div className="space-y-3">
                {pendingCashiers.map((cashier: any, index: number) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-md border"
                    data-testid={`card-pending-cashier-${index}`}
                  >
                    <div>
                      <p className="font-medium">{cashier.firstName} {cashier.lastName}</p>
                      <p className="text-sm text-muted-foreground">@{cashier.username}</p>
                    </div>
                    <Badge variant="outline">Pending</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No pending approvals
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
