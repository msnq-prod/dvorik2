import { sql } from "drizzle-orm";
import { relations } from "drizzle-orm";
import { pgEnum, pgTable, uuid, bigint, text, varchar, boolean, timestamp, jsonb, numeric, integer, date, index, uniqueIndex, bigserial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const adminRoleEnum = pgEnum("admin_role", ["admin", "marketing", "cashier", "read_only"]);
export const discountTemplateTypeEnum = pgEnum("discount_template_type", ["subscription", "birthday", "manual", "campaign"]);
export const discountValueTypeEnum = pgEnum("discount_value_type", ["percent", "amount"]);
export const discountStatusEnum = pgEnum("discount_status", ["active", "redeemed", "expired", "cancelled"]);
export const broadcastStatusEnum = pgEnum("broadcast_status", ["draft", "scheduled", "sending", "completed", "failed"]);
export const userGenderEnum = pgEnum("user_gender", ["male", "female", "unspecified"]);
export const userStatusEnum = pgEnum("user_status", ["active", "inactive", "blocked"]);
export const referralEventEnum = pgEnum("referral_event", ["click", "start", "register", "redeem"]);

// Tables
export const admins = pgTable("admins", {
  id: uuid("id").defaultRandom().primaryKey(),
  telegramId: bigint("telegram_id", { mode: "bigint" }).notNull(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  role: adminRoleEnum("role").notNull(),
  permissions: jsonb("permissions").notNull().default(sql`'{}'::jsonb`),
  canBroadcastFromChat: boolean("can_broadcast_from_chat").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  telegramUidx: uniqueIndex("admins_telegram_uidx").on(t.telegramId),
  roleIdx: index("admins_role_idx").on(t.role),
}));

export const leadSources = pgTable("lead_sources", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: varchar("code", { length: 64 }).notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  codeUidx: uniqueIndex("lead_sources_code_uidx").on(t.code),
}));

export const referralCampaigns = pgTable("referral_campaigns", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: varchar("code", { length: 64 }).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  createdByAdminId: uuid("created_by_admin_id").references(() => admins.id, { onDelete: "set null" }),
  isActive: boolean("is_active").notNull().default(true),
  isTest: boolean("is_test").notNull().default(false),
  clickCount: integer("click_count").notNull().default(0),
  registrationCount: integer("registration_count").notNull().default(0),
  redemptionCount: integer("redemption_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  codeUidx: uniqueIndex("referral_campaigns_code_uidx").on(t.code),
}));

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  telegramId: bigint("telegram_id", { mode: "bigint" }).notNull(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  gender: userGenderEnum("gender").notNull().default("unspecified"),
  birthday: date("birthday"),
  isSubscribed: boolean("is_subscribed").notNull().default(false),
  subscriptionCheckedAt: timestamp("subscription_checked_at", { withTimezone: true }),
  sourceId: uuid("source_id").references(() => leadSources.id, { onDelete: "set null" }),
  referralCampaignId: uuid("referral_campaign_id").references(() => referralCampaigns.id, { onDelete: "set null" }),
  referralToken: varchar("referral_token", { length: 128 }),
  tags: jsonb("tags").notNull().default(sql`'[]'::jsonb`),
  status: userStatusEnum("status").notNull().default("active"),
  notes: text("notes"),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  telegramUidx: uniqueIndex("users_telegram_uidx").on(t.telegramId),
  birthdayIdx: index("users_birthday_idx").on(t.birthday),
  statusIdx: index("users_status_idx").on(t.status),
}));

export const cashiers = pgTable("cashiers", {
  id: uuid("id").defaultRandom().primaryKey(),
  telegramId: bigint("telegram_id", { mode: "bigint" }).notNull(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  approvedByAdminId: uuid("approved_by_admin_id").references(() => admins.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  isActive: boolean("is_active").notNull().default(false),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  telegramUidx: uniqueIndex("cashiers_telegram_uidx").on(t.telegramId),
  activeIdx: index("cashiers_active_idx").on(t.isActive),
}));

export const discountTemplates = pgTable("discount_templates", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  type: discountTemplateTypeEnum("type").notNull(),
  valueType: discountValueTypeEnum("value_type").notNull().default("percent"),
  valueAmount: numeric("value_amount", { precision: 6, scale: 2 }).notNull(),
  durationDays: integer("duration_days").notNull(),
  repeatRule: jsonb("repeat_rule").notNull().default(sql`'{}'::jsonb`),
  triggerCondition: jsonb("trigger_condition").notNull().default(sql`'{}'::jsonb`),
  textTemplate: text("text_template").notNull(),
  reminderRules: jsonb("reminder_rules").notNull().default(sql`'[]'::jsonb`),
  isActive: boolean("is_active").notNull().default(true),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  typeIdx: index("discount_templates_type_idx").on(t.type),
}));

export const discounts = pgTable("discounts", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: varchar("code", { length: 7 }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  templateId: uuid("template_id").references(() => discountTemplates.id, { onDelete: "set null" }),
  issuedByAdminId: uuid("issued_by_admin_id").references(() => admins.id, { onDelete: "set null" }),
  issuedAt: timestamp("issued_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  redeemedAt: timestamp("redeemed_at", { withTimezone: true }),
  redeemedByCashierId: uuid("redeemed_by_cashier_id").references(() => cashiers.id, { onDelete: "set null" }),
  status: discountStatusEnum("status").notNull().default("active"),
  metadata: jsonb("metadata").notNull().default(sql`'{}'::jsonb`),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  codeUidx: uniqueIndex("discounts_code_uidx").on(t.code),
  userIdx: index("discounts_user_idx").on(t.userId),
  statusIdx: index("discounts_status_idx").on(t.status),
  expiresIdx: index("discounts_expires_idx").on(t.expiresAt),
}));

export const discountUsageLogs = pgTable("discount_usage_logs", {
  id: bigserial("id", { mode: "bigint" }).primaryKey(),
  discountId: uuid("discount_id").references(() => discounts.id, { onDelete: "set null" }),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  cashierId: uuid("cashier_id").references(() => cashiers.id, { onDelete: "set null" }),
  templateId: uuid("template_id").references(() => discountTemplates.id, { onDelete: "set null" }),
  attemptCode: varchar("attempt_code", { length: 32 }).notNull(),
  success: boolean("success").notNull(),
  errorCode: varchar("error_code", { length: 64 }),
  errorMessage: text("error_message"),
  source: text("source"),
  metadata: jsonb("metadata").notNull().default(sql`'{}'::jsonb`),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  discountIdx: index("discount_usage_discount_idx").on(t.discountId),
  createdIdx: index("discount_usage_created_idx").on(t.createdAt),
}));

export const broadcasts = pgTable("broadcasts", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title"),
  text: text("text").notNull(),
  mediaType: varchar("media_type", { length: 32 }),
  mediaUrl: text("media_url"),
  buttons: jsonb("buttons").notNull().default(sql`'[]'::jsonb`),
  audienceFilter: jsonb("audience_filter").notNull().default(sql`'{}'::jsonb`),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  status: broadcastStatusEnum("status").notNull().default("draft"),
  ratePerMinute: integer("rate_per_minute"),
  batchSize: integer("batch_size"),
  totalRecipients: integer("total_recipients"),
  createdByAdminId: uuid("created_by_admin_id").references(() => admins.id, { onDelete: "set null" }),
  sentFromBot: boolean("sent_from_bot").notNull().default(false),
  lastError: text("last_error"),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  statusIdx: index("broadcasts_status_idx").on(t.status),
  scheduleIdx: index("broadcasts_schedule_idx").on(t.scheduledAt),
}));

export const broadcastLogs = pgTable("broadcast_logs", {
  id: bigserial("id", { mode: "bigint" }).primaryKey(),
  broadcastId: uuid("broadcast_id").references(() => broadcasts.id, { onDelete: "cascade" }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
  success: boolean("success").notNull(),
  errorCode: varchar("error_code", { length: 64 }),
  errorMessage: text("error_message"),
  attempt: integer("attempt").notNull().default(1),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  broadcastIdx: index("broadcast_logs_broadcast_idx").on(t.broadcastId),
  userIdx: index("broadcast_logs_user_idx").on(t.userId),
}));

export const settings = pgTable("settings", {
  key: varchar("key", { length: 128 }).primaryKey(),
  value: jsonb("value").notNull(),
  description: text("description"),
  updatedByAdminId: uuid("updated_by_admin_id").references(() => admins.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const subscriptionChecks = pgTable("subscription_checks", {
  id: bigserial("id", { mode: "bigint" }).primaryKey(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  channelId: bigint("channel_id", { mode: "bigint" }).notNull(),
  isSubscribed: boolean("is_subscribed").notNull(),
  checkedAt: timestamp("checked_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  payload: jsonb("payload").notNull().default(sql`'{}'::jsonb`),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  userChannelIdx: index("subscription_checks_user_channel_idx").on(t.userId, t.channelId),
}));

export const referralEvents = pgTable("referral_events", {
  id: bigserial("id", { mode: "bigint" }).primaryKey(),
  campaignId: uuid("campaign_id").references(() => referralCampaigns.id, { onDelete: "cascade" }).notNull(),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  telegramId: bigint("telegram_id", { mode: "bigint" }),
  eventType: referralEventEnum("event_type").notNull(),
  metadata: jsonb("metadata").notNull().default(sql`'{}'::jsonb`),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  campaignIdx: index("referral_events_campaign_idx").on(t.campaignId, t.eventType),
}));

export const auditLogs = pgTable("audit_logs", {
  id: bigserial("id", { mode: "bigint" }).primaryKey(),
  actorAdminId: uuid("actor_admin_id").references(() => admins.id, { onDelete: "set null" }),
  actorRole: adminRoleEnum("actor_role").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: uuid("entity_id"),
  diff: jsonb("diff").notNull().default(sql`'{}'::jsonb`),
  isTest: boolean("is_test").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, t => ({
  actorIdx: index("audit_logs_actor_idx").on(t.actorAdminId),
  entityIdx: index("audit_logs_entity_idx").on(t.entityType, t.entityId),
}));

// Relations
export const adminsRelations = relations(admins, ({ many }) => ({
  createdCampaigns: many(referralCampaigns),
  issuedDiscounts: many(discounts),
  createdBroadcasts: many(broadcasts),
  auditLogs: many(auditLogs),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  source: one(leadSources, {
    fields: [users.sourceId],
    references: [leadSources.id],
  }),
  referralCampaign: one(referralCampaigns, {
    fields: [users.referralCampaignId],
    references: [referralCampaigns.id],
  }),
  discounts: many(discounts),
  subscriptionChecks: many(subscriptionChecks),
  referralEvents: many(referralEvents),
}));

export const discountsRelations = relations(discounts, ({ one, many }) => ({
  user: one(users, {
    fields: [discounts.userId],
    references: [users.id],
  }),
  template: one(discountTemplates, {
    fields: [discounts.templateId],
    references: [discountTemplates.id],
  }),
  issuedByAdmin: one(admins, {
    fields: [discounts.issuedByAdminId],
    references: [admins.id],
  }),
  redeemedByCashier: one(cashiers, {
    fields: [discounts.redeemedByCashierId],
    references: [cashiers.id],
  }),
  usageLogs: many(discountUsageLogs),
}));

export const broadcastsRelations = relations(broadcasts, ({ one, many }) => ({
  createdByAdmin: one(admins, {
    fields: [broadcasts.createdByAdminId],
    references: [admins.id],
  }),
  logs: many(broadcastLogs),
}));

export const referralCampaignsRelations = relations(referralCampaigns, ({ one, many }) => ({
  createdByAdmin: one(admins, {
    fields: [referralCampaigns.createdByAdminId],
    references: [admins.id],
  }),
  events: many(referralEvents),
  users: many(users),
}));

export const cashiersRelations = relations(cashiers, ({ one, many }) => ({
  approvedByAdmin: one(admins, {
    fields: [cashiers.approvedByAdminId],
    references: [admins.id],
  }),
  redemptions: many(discounts),
  usageLogs: many(discountUsageLogs),
}));

export const discountTemplatesRelations = relations(discountTemplates, ({ many }) => ({
  discounts: many(discounts),
  usageLogs: many(discountUsageLogs),
}));

export const discountUsageLogsRelations = relations(discountUsageLogs, ({ one }) => ({
  discount: one(discounts, {
    fields: [discountUsageLogs.discountId],
    references: [discounts.id],
  }),
  user: one(users, {
    fields: [discountUsageLogs.userId],
    references: [users.id],
  }),
  cashier: one(cashiers, {
    fields: [discountUsageLogs.cashierId],
    references: [cashiers.id],
  }),
  template: one(discountTemplates, {
    fields: [discountUsageLogs.templateId],
    references: [discountTemplates.id],
  }),
}));

export const broadcastLogsRelations = relations(broadcastLogs, ({ one }) => ({
  broadcast: one(broadcasts, {
    fields: [broadcastLogs.broadcastId],
    references: [broadcasts.id],
  }),
  user: one(users, {
    fields: [broadcastLogs.userId],
    references: [users.id],
  }),
}));

export const subscriptionChecksRelations = relations(subscriptionChecks, ({ one }) => ({
  user: one(users, {
    fields: [subscriptionChecks.userId],
    references: [users.id],
  }),
}));

export const referralEventsRelations = relations(referralEvents, ({ one }) => ({
  campaign: one(referralCampaigns, {
    fields: [referralEvents.campaignId],
    references: [referralCampaigns.id],
  }),
  user: one(users, {
    fields: [referralEvents.userId],
    references: [users.id],
  }),
}));

export const leadSourcesRelations = relations(leadSources, ({ many }) => ({
  users: many(users),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  actor: one(admins, {
    fields: [auditLogs.actorAdminId],
    references: [admins.id],
  }),
}));

export const settingsRelations = relations(settings, ({ one }) => ({
  updatedByAdmin: one(admins, {
    fields: [settings.updatedByAdminId],
    references: [admins.id],
  }),
}));

// Insert schemas
export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCashierSchema = createInsertSchema(cashiers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDiscountTemplateSchema = createInsertSchema(discountTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDiscountSchema = createInsertSchema(discounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBroadcastSchema = createInsertSchema(broadcasts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReferralCampaignSchema = createInsertSchema(referralCampaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLeadSourceSchema = createInsertSchema(leadSources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSettingSchema = createInsertSchema(settings).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertDiscountUsageLogSchema = createInsertSchema(discountUsageLogs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBroadcastLogSchema = createInsertSchema(broadcastLogs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSubscriptionCheckSchema = createInsertSchema(subscriptionChecks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReferralEventSchema = createInsertSchema(referralEvents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Cashier = typeof cashiers.$inferSelect;
export type InsertCashier = z.infer<typeof insertCashierSchema>;
export type DiscountTemplate = typeof discountTemplates.$inferSelect;
export type InsertDiscountTemplate = z.infer<typeof insertDiscountTemplateSchema>;
export type Discount = typeof discounts.$inferSelect;
export type InsertDiscount = z.infer<typeof insertDiscountSchema>;
export type Broadcast = typeof broadcasts.$inferSelect;
export type InsertBroadcast = z.infer<typeof insertBroadcastSchema>;
export type ReferralCampaign = typeof referralCampaigns.$inferSelect;
export type InsertReferralCampaign = z.infer<typeof insertReferralCampaignSchema>;
export type LeadSource = typeof leadSources.$inferSelect;
export type InsertLeadSource = z.infer<typeof insertLeadSourceSchema>;
export type Setting = typeof settings.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type DiscountUsageLog = typeof discountUsageLogs.$inferSelect;
export type BroadcastLog = typeof broadcastLogs.$inferSelect;
export type SubscriptionCheck = typeof subscriptionChecks.$inferSelect;
export type InsertSubscriptionCheck = z.infer<typeof insertSubscriptionCheckSchema>;
export type ReferralEvent = typeof referralEvents.$inferSelect;
export type InsertReferralEvent = z.infer<typeof insertReferralEventSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type InsertDiscountUsageLog = z.infer<typeof insertDiscountUsageLogSchema>;
export type InsertBroadcastLog = z.infer<typeof insertBroadcastLogSchema>;
