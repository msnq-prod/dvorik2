import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Send, Calendar } from "lucide-react";

export default function Broadcasts() {
  const { data: broadcasts, isLoading } = useQuery({
    queryKey: ["/api/broadcasts"],
  });

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "outline" | "destructive"; label: string }> = {
      draft: { variant: "secondary", label: "Draft" },
      scheduled: { variant: "outline", label: "Scheduled" },
      sending: { variant: "default", label: "Sending" },
      completed: { variant: "default", label: "Completed" },
      failed: { variant: "destructive", label: "Failed" },
    };
    const config = variants[status] || { variant: "outline" as const, label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-page-title">Broadcasts</h1>
          <p className="text-muted-foreground">Create and manage message broadcasts</p>
        </div>
        <Button data-testid="button-create-broadcast">
          <Plus className="h-4 w-4 mr-2" />
          Create Broadcast
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Broadcasts</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : broadcasts && broadcasts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Message Preview</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Recipients</TableHead>
                  <TableHead>Scheduled</TableHead>
                  <TableHead>Sent</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {broadcasts.map((broadcast: any, index: number) => (
                  <TableRow key={broadcast.id} data-testid={`row-broadcast-${index}`}>
                    <TableCell className="font-medium">
                      {broadcast.title || "Untitled"}
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <p className="truncate text-sm text-muted-foreground">
                        {broadcast.text}
                      </p>
                    </TableCell>
                    <TableCell>{getStatusBadge(broadcast.status)}</TableCell>
                    <TableCell className="font-semibold">
                      {broadcast.totalRecipients?.toLocaleString() || "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {broadcast.scheduledAt ? (
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(broadcast.scheduledAt).toLocaleString()}
                        </div>
                      ) : (
                        "—"
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {broadcast.sentAt ? new Date(broadcast.sentAt).toLocaleString() : "—"}
                    </TableCell>
                    <TableCell className="text-sm">
                      {broadcast.createdByAdmin?.firstName || "System"}
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" data-testid={`button-view-broadcast-${index}`}>
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No broadcasts found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
