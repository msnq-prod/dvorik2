import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Plus } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Discounts() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: discounts, isLoading } = useQuery({
    queryKey: ["/api/discounts", { search: searchQuery, status: statusFilter }],
  });

  const getStatusBadge = (status: string, expiresAt: string | null) => {
    if (status === "redeemed") {
      return <Badge variant="secondary">Redeemed</Badge>;
    }
    if (status === "expired" || (expiresAt && new Date(expiresAt) < new Date())) {
      return <Badge variant="destructive">Expired</Badge>;
    }
    return <Badge variant="default">Active</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-page-title">Discount Codes</h1>
          <p className="text-muted-foreground">View and manage all discount codes</p>
        </div>
        <Button data-testid="button-create-discount">
          <Plus className="h-4 w-4 mr-2" />
          Create Discount
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>All Discounts</CardTitle>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by code..."
                  className="pl-9 w-full sm:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value.toUpperCase())}
                  data-testid="input-search-discounts"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[150px]" data-testid="select-status-filter">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="redeemed">Redeemed</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(10)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : discounts && discounts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Template</TableHead>
                  <TableHead>Issued</TableHead>
                  <TableHead>Expires</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Redeemed By</TableHead>
                  <TableHead>Redeemed At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {discounts.map((discount: any, index: number) => (
                  <TableRow key={discount.id} data-testid={`row-discount-${index}`}>
                    <TableCell className="font-mono font-bold text-lg">
                      {discount.code}
                    </TableCell>
                    <TableCell>
                      {discount.user?.firstName} {discount.user?.lastName}
                    </TableCell>
                    <TableCell>{discount.template?.name || "—"}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(discount.issuedAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {discount.expiresAt ? new Date(discount.expiresAt).toLocaleDateString() : "Never"}
                    </TableCell>
                    <TableCell>{getStatusBadge(discount.status, discount.expiresAt)}</TableCell>
                    <TableCell>
                      {discount.redeemedByCashier ? (
                        <span>
                          {discount.redeemedByCashier.firstName} {discount.redeemedByCashier.lastName}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {discount.redeemedAt ? new Date(discount.redeemedAt).toLocaleString() : "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No discounts found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
