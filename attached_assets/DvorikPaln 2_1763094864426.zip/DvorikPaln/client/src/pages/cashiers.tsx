import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Check, X, UserCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Cashiers() {
  const { toast } = useToast();
  
  const { data: cashiers, isLoading } = useQuery({
    queryKey: ["/api/cashiers"],
  });

  const approveMutation = useMutation({
    mutationFn: (cashierId: string) => 
      apiRequest("POST", `/api/cashiers/${cashierId}/approve`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cashiers"] });
      toast({
        title: "Cashier approved",
        description: "The cashier has been approved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve cashier",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: (cashierId: string) => 
      apiRequest("POST", `/api/cashiers/${cashierId}/reject`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cashiers"] });
      toast({
        title: "Cashier rejected",
        description: "The cashier request has been rejected",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject cashier",
        variant: "destructive",
      });
    },
  });

  const pending = cashiers?.filter((c: any) => !c.isActive && !c.approvedAt) || [];
  const approved = cashiers?.filter((c: any) => c.isActive) || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-page-title">Cashiers</h1>
        <p className="text-muted-foreground">Manage cashier access and approvals</p>
      </div>

      {/* Pending Approvals */}
      {pending.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5" />
              Pending Approvals ({pending.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pending.map((cashier: any, index: number) => (
                <div
                  key={cashier.id}
                  className="flex items-center justify-between p-4 rounded-md border"
                  data-testid={`card-pending-cashier-${index}`}
                >
                  <div className="space-y-1">
                    <p className="font-medium">
                      {cashier.firstName} {cashier.lastName}
                    </p>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <span>@{cashier.username || "no username"}</span>
                      <span>•</span>
                      <span className="font-mono">{cashier.telegramId}</span>
                      <span>•</span>
                      <span>{new Date(cashier.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => approveMutation.mutate(cashier.id)}
                      disabled={approveMutation.isPending}
                      data-testid={`button-approve-cashier-${index}`}
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => rejectMutation.mutate(cashier.id)}
                      disabled={rejectMutation.isPending}
                      data-testid={`button-reject-cashier-${index}`}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Reject
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Approved Cashiers */}
      <Card>
        <CardHeader>
          <CardTitle>Approved Cashiers</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : approved.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Username</TableHead>
                  <TableHead>Telegram ID</TableHead>
                  <TableHead>Approved By</TableHead>
                  <TableHead>Approved At</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {approved.map((cashier: any, index: number) => (
                  <TableRow key={cashier.id} data-testid={`row-cashier-${index}`}>
                    <TableCell className="font-medium">
                      {cashier.firstName} {cashier.lastName}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      @{cashier.username || "—"}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {cashier.telegramId}
                    </TableCell>
                    <TableCell>
                      {cashier.approvedByAdmin?.firstName || "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {cashier.approvedAt ? new Date(cashier.approvedAt).toLocaleDateString() : "—"}
                    </TableCell>
                    <TableCell>
                      {cashier.isActive ? (
                        <Badge variant="default">Active</Badge>
                      ) : (
                        <Badge variant="secondary">Inactive</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" data-testid={`button-deactivate-cashier-${index}`}>
                        Deactivate
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No approved cashiers yet</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
