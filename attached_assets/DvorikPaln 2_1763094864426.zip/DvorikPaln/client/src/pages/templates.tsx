import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Edit, Trash2, Gift, Calendar, Target, Zap } from "lucide-react";

export default function Templates() {
  const { data: templates, isLoading } = useQuery({
    queryKey: ["/api/templates"],
  });

  const getTypeIcon = (type: string) => {
    const icons: Record<string, any> = {
      subscription: Gift,
      birthday: Calendar,
      campaign: Target,
      manual: Zap,
    };
    return icons[type] || Gift;
  };

  const getTypeBadge = (type: string) => {
    const variants: Record<string, { label: string; variant: "default" | "secondary" | "outline" }> = {
      subscription: { label: "Subscription", variant: "default" },
      birthday: { label: "Birthday", variant: "secondary" },
      campaign: { label: "Campaign", variant: "outline" },
      manual: { label: "Manual", variant: "outline" },
    };
    const config = variants[type] || { label: type, variant: "outline" as const };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-page-title">Discount Templates</h1>
          <p className="text-muted-foreground">Configure discount rules and triggers</p>
        </div>
        <Button data-testid="button-create-template">
          <Plus className="h-4 w-4 mr-2" />
          Create Template
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          [...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-24 mt-2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))
        ) : templates && templates.length > 0 ? (
          templates.map((template: any, index: number) => {
            const TypeIcon = getTypeIcon(template.type);
            return (
              <Card key={template.id} data-testid={`card-template-${index}`} className="flex flex-col">
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <TypeIcon className="h-5 w-5 text-primary" />
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                    </div>
                    {template.isActive ? (
                      <Badge variant="default">Active</Badge>
                    ) : (
                      <Badge variant="secondary">Inactive</Badge>
                    )}
                  </div>
                  <CardDescription>{getTypeBadge(template.type)}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Discount:</span>
                      <span className="font-semibold">
                        {template.valueType === "percent" 
                          ? `${template.valueAmount}%` 
                          : `${template.valueAmount} ₽`}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Duration:</span>
                      <span className="font-semibold">{template.durationDays} days</span>
                    </div>
                    {template.repeatRule && template.repeatRule.type && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Repeat:</span>
                        <span className="font-semibold capitalize">
                          {template.repeatRule.type === "interval" 
                            ? `Every ${template.repeatRule.months} month(s)` 
                            : template.repeatRule.type}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="pt-2 border-t">
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {template.textTemplate}
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1" data-testid={`button-edit-template-${index}`}>
                    <Edit className="h-3 w-3 mr-1" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm" data-testid={`button-delete-template-${index}`}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </CardFooter>
              </Card>
            );
          })
        ) : (
          <Card className="col-span-full">
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No templates found. Create your first template to get started.</p>
              <Button className="mt-4" data-testid="button-create-first-template">
                <Plus className="h-4 w-4 mr-2" />
                Create Template
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
