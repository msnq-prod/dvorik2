# Design Guidelines: Мармеладный дворик Loyalty System

## Design Approach

**Selected Approach:** Design System with Modern Admin Dashboard Reference

**Rationale:** This is a utility-focused admin application requiring clear information hierarchy, efficient workflows, and data-dense interfaces. Drawing inspiration from Linear's clean admin aesthetics combined with Stripe's restrained professionalism, while maintaining approachability for non-technical users (cashiers, marketers).

**Key Design Principles:**
1. **Clarity Over Decoration** - Every element serves a functional purpose
2. **Scannable Information** - Dense data presented in digestible chunks
3. **Action-Oriented** - Clear CTAs for primary workflows (approve cashier, send broadcast, redeem code)
4. **Trust & Reliability** - Professional appearance befitting financial/loyalty operations

---

## Core Design Elements

### A. Typography

**Font Families:**
- Primary: Inter (400, 500, 600, 700) - for UI, tables, forms
- Monospace: JetBrains Mono (400, 500) - for discount codes, IDs, technical data

**Typography Scale:**
- Hero/Page Titles: text-4xl font-bold (36px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-lg font-semibold (18px)
- Body Text: text-base font-normal (16px)
- Labels/Metadata: text-sm font-medium (14px)
- Captions/Timestamps: text-xs (12px)
- Discount Codes: text-2xl font-mono font-bold tracking-wider

---

### B. Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4, p-6
- Section spacing: space-y-6, space-y-8
- Card gaps: gap-4
- Form field spacing: space-y-4
- List item spacing: space-y-2

**Grid Structure:**
- Main dashboard: 12-column grid with 240px fixed sidebar
- Content area: max-w-7xl mx-auto px-6
- Forms: Single column max-w-2xl for focused data entry
- Tables: Full-width within content constraints
- Cards grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6

---

## C. Component Library

### Navigation & Layout

**Sidebar Navigation (240px fixed):**
- Sections: Dashboard, Users, Discount Codes, Templates, Broadcasts, Campaigns, Cashiers, Logs, Settings
- Active state indicated with subtle background and border accent
- Icons from Heroicons (outline style)
- Collapsible on mobile

**Top Bar:**
- User profile dropdown (role badge visible)
- Notification bell for pending approvals
- Quick actions button
- Breadcrumb navigation for deep pages

### Data Display

**Tables:**
- Striped rows for improved scannability
- Sticky header on scroll
- Row actions appear on hover (approve, edit, delete)
- Pagination with page size selector (10, 25, 50, 100)
- Sort indicators on column headers
- Status badges (active/inactive, redeemed/available, approved/pending)

**Stat Cards:**
- 4-column grid on desktop (2 on tablet, 1 on mobile)
- Large number display (text-3xl font-bold)
- Trend indicator with small arrow icon
- Subtitle describing metric
- Optional sparkline chart area

**Status Badges:**
- Pill-shaped, compact (px-2 py-1 text-xs rounded-full)
- Success states: subtle green background with darker green text
- Pending states: amber/yellow treatment
- Inactive/expired: gray treatment
- Error states: red treatment

### Forms & Inputs

**Form Layout:**
- Labels above inputs (font-medium text-sm mb-2)
- Input fields with border, rounded corners, padding p-3
- Helper text below (text-xs text-gray-600)
- Inline validation messages
- Required field indicator (asterisk)

**Broadcast Message Composer:**
- Large textarea (min-h-48) for message content
- Live character counter
- Media upload dropzone with preview
- Button builder for inline keyboard creation
- Audience selector with chip-based filter display

**Discount Code Input:**
- Monospace font, larger text (text-xl)
- Auto-uppercase transform
- Format guide: "ААА-1234" pattern
- Validation feedback in real-time

### Interactive Elements

**Primary Actions:**
- Solid buttons with medium padding (px-6 py-3)
- Prominent for critical actions (Send Broadcast, Approve Cashier, Redeem Code)
- Loading spinner replaces text during processing

**Secondary Actions:**
- Outlined buttons with border
- Used for cancel, back, or alternative paths

**Danger Actions:**
- Red treatment for destructive operations
- Require confirmation modal

**Modals:**
- Centered overlay with backdrop blur
- Max width appropriate to content (sm for confirmations, lg for forms)
- Clear header, content area, action footer
- ESC to close, click outside to dismiss (with unsaved changes warning)

### Specialized Components

**Redemption Log Viewer:**
- Timeline-style layout showing chronological redemptions
- Each entry shows: timestamp, user info, cashier info, code, discount amount
- Expandable details for full transaction context
- Filter by date range, cashier, user, template

**Referral Campaign Card:**
- Displays campaign name and generated link
- QR code for easy sharing
- Statistics: clicks, registrations, redemptions
- Copy link button with success toast

**Birthday Schedule Calendar:**
- Monthly view showing upcoming birthdays
- Click date to see users with birthdays
- Indicator for auto-generated discount status

**User Profile Panel:**
- Avatar or initials circle
- Username and full name
- Tag chips (VIP, Subscriber, etc.)
- Active discounts list with codes prominently displayed
- Redemption history table
- Edit profile action

---

## Images

No hero images needed for this admin application. Focus remains on functional data interfaces.

**Contextual Imagery:**
- User avatars (Telegram profile photos or generated initials)
- Empty state illustrations for zero-data scenarios (custom SVG placeholders with friendly messaging)
- QR codes for referral campaigns (dynamically generated)

---

## Key Page Layouts

**Dashboard:** 
4 stat cards at top, 2-column grid below with "Recent Redemptions" table and "Pending Approvals" list

**Broadcast Creation:**
Split layout - left side for message composer, right side for audience preview and settings

**Discount Templates:**
Card grid displaying each template with edit/delete actions, "Create New Template" card prominent

**User Management:**
Full-width searchable table with filters sidebar (subscription status, tags, registration date range)

**Cashier Approval Queue:**
List view of pending cashier registration requests with approve/reject actions and applicant details